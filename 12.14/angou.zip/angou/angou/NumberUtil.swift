//
//  NumberUtil.swift
//  costpang
//
//  Created by FENGBOLAI on 15/7/29.
//  Copyright (c) 2015年 FENGBOLAI. All rights reserved.
//

import Foundation

class NumberUtil: NSObject{
    // 小数点后1位
//    static func getFormatFloatPrice(_ price: CGFloat) -> String {
//        return String(format: "%.1f", price)
//    }
}

